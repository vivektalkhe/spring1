package com.cg.appl.dao;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;

public interface TraineeDao {
	
	Trainee getTraineeDetails(int traineeId) throws TraineeExceptions;
	List<Trainee> showAllDetails() throws TraineeExceptions;
	Trainee insertNewTrainee(Trainee trainee) throws TraineeExceptions,RollbackException;
	
}
