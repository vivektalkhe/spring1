package com.cg.appl.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.TraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;

@Service("traineeService")
public class TraineeServicesImpl implements TraineeServices {

	private TraineeDao dao;

	@Resource(name = "traineeDao")
	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeExceptions {
		Trainee trainee = null;
		try {
			trainee = dao.getTraineeDetails(traineeId);
			return trainee;
		} catch (TraineeExceptions e) {

			throw new TraineeExceptions("Your record is not found", e);

		}

	}

	@Override
	public List<Trainee> showAllDetails() throws TraineeExceptions {
		
		try {
			List<Trainee> traineeList= dao.showAllDetails();
			return traineeList;
		} catch (TraineeExceptions e) {
			
			throw new TraineeExceptions("Your List is not retrieved",e);
		}
	}
	@Transactional
	@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeExceptions {
		// TODO Auto-generated method stub
		return dao.insertNewTrainee(trainee);
	}

}
