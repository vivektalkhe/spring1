package com.cg.appl.commons;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("companyDetails")
public class CompanyDetails {
	@Value("iGate")
	private String companyName;
	@Value("Always Ahead Of Time")
	private String companyMotto;
	@Value("104")
	private int niftyRank;
	@Resource
	private Address addr;
	private List<String> directors;
	private Set<String> branches;
	private Map<String,String> branchAddr;
	private Properties ipAddress;

	
	public CompanyDetails(String companyMotto) {

		System.out.println("In Constructor for String");
		this.companyMotto=companyMotto;
		}
	
	public CompanyDetails()
	{
		
	}
	
	
	public String getCompanyName() {
		return companyName;
	}
	@Value("Capgemini")
	public void setCompanyName(String companyName) {//companyName
		this.companyName = companyName;
	}

	public String getCompanyMotto() {
		return companyMotto;
	}

	public void setCompanyMotto(String companyMotto) {//companyMotto
		this.companyMotto = companyMotto;
	}

	public int getNiftyRank() {
		return niftyRank;
	}

	public void setNiftyRank(int niftyRank) {//niftyRank
		this.niftyRank = niftyRank;
	}
	
	

	public Address getAddr() { //addr
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	
	public List<String> getDirectors() {
		return directors;
	}

	public void setDirectors(List<String> directors) {
		this.directors = directors;
	}

	
	
	public Set<String> getBranches() {
		return branches;
	}

	public void setBranches(Set<String> branches) {
		this.branches = branches;
	}

	
	public Map<String, String> getBranchAddr() {
		return branchAddr;
	}

	public void setBranchAddr(Map<String, String> branchAddr) {
		this.branchAddr = branchAddr;
	}

	
	
	
	public Properties getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(Properties ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMotto="
				+ companyMotto + ", niftyRank=" + niftyRank + ", addr=" + addr
				+ ", \ndirectors=" + directors + ", \nbranches=" + branches
				+ ", \nbranchAddr=" + branchAddr + ", \nipAddress=" + ipAddress
				+ "]";
	}



	


	
}
