package com.cg.appl.commons;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("results")
public class Results {
	@Value("#{operands.val1}")
	private int result1;
	
	@Value("#{operands.val2}")
			private int result2;
	
	@Value("#{operands.calcVal3()}")
	private int result3;
	
	@Value("#{operands.val1 + operands.val2}")
	private int result4;
	
	@Value("#{operands.val1 lt operands.val2}")
	private boolean isVal1LessVal2;
	
	@Value("#{operands.val1 gt operands.val2}")
	private boolean isCondition;

	@Override
	public String toString() {
		return "Results [result1=" + result1 + ", result2=" + result2
				+ ", result3=" + result3 + ", result4=" + result4
				+ ", isVal1LessVal2=" + isVal1LessVal2 + ", isCondition="
				+ isCondition + "]";
	}

	
	
	
	
	
	

}
