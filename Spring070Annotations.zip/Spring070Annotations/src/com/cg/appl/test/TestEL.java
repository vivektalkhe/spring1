package com.cg.appl.test;

import org.springframework.context.ApplicationContext;

import com.cg.appl.commons.CompanyDetails;
import com.cg.appl.commons.Results;
import com.cg.appl.util.SpringUtil;

public class TestEL {


	public static void main(String[] args) {

		
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		Results results=(Results) ctx.getBean("results");
		System.out.println(results);
	}

}
